# AutoCut
ভিডিও থেকে কথার মাঝের গ্যাপ কাটে, প্রতি কাটে ১ সেকেন্ড ব্ল্যাক দেয়, আর Alight Motion XML থেকে কালার গ্রেডিং লাগায়।

## APK বানানো (GitHub Actions)
1. GitHub-এ নতুন repository বানান, এই ফোল্ডারের সব ফাইল আপলোড করুন (branch: main)।
2. Actions ট্যাব → "Build APK" চলবে (৫-১০ মিনিট)।
3. রান শেষে নিচে Artifacts থেকে **AutoCut-apk** ডাউনলোড করে ফোনে ইনস্টল করুন।
