package com.example.autocut

import android.content.Context
import android.net.Uri
import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.FFmpegKitConfig
import com.arthenica.ffmpegkit.FFprobeKit
import com.arthenica.ffmpegkit.ReturnCode
import java.io.File
import java.util.Locale
import kotlin.math.max
import kotlin.math.min

class Processor(private val ctx: Context) {

    data class Seg(val s: Double, val e: Double)

    private fun f(v: Double) = String.format(Locale.US, "%.3f", v)

    /**
     * ১) নীরবতা খুঁজে বের করে ২) কথার অংশগুলো রাখে ৩) প্রতি কাটে ১ সেকেন্ড ব্ল্যাক বসায়
     * ৪) কালার গ্রেডিং লাগিয়ে এক্সপোর্ট করে।
     */
    fun process(
        input: Uri,
        grade: Grade,
        noiseDb: Int,
        minGap: Double,
        blackSec: Double,
        onStatus: (String) -> Unit,
        onProgress: (Int) -> Unit
    ): File {
        val src = FFmpegKitConfig.getSafParameterForRead(ctx, input)

        // --- ভিডিওর তথ্য ---
        onStatus("ভিডিও বিশ্লেষণ হচ্ছে…")
        val info = FFprobeKit.getMediaInformation(src).mediaInformation
            ?: error("ভিডিও পড়া যায়নি")
        val duration = info.duration?.toDoubleOrNull() ?: error("ভিডিওর দৈর্ঘ্য পাওয়া যায়নি")
        val vs = info.streams.firstOrNull { it.type == "video" } ?: error("ভিডিও স্ট্রিম নেই")
        if (info.streams.none { it.type == "audio" }) error("ভিডিওতে অডিও নেই")

        var w = (vs.width ?: 0L).toInt()
        var h = (vs.height ?: 0L).toInt()
        val props = vs.allProperties
        var rot = props?.optJSONArray("side_data_list")?.optJSONObject(0)?.optInt("rotation", 0) ?: 0
        if (rot == 0) rot = props?.optJSONObject("tags")?.optString("rotate")?.toIntOrNull() ?: 0
        if (Math.abs(rot) % 180 == 90) { val t = w; w = h; h = t }
        w = w and 1.inv(); h = h and 1.inv()

        var fps = vs.averageFrameRate ?: "30"
        if (fps.startsWith("0") || !fps.matches(Regex("[0-9./]+"))) fps = "30"

        // --- নীরবতা খোঁজা ---
        onStatus("কথার ফাঁক খোঁজা হচ্ছে…")
        val det = FFmpegKit.executeWithArguments(arrayOf(
            "-hide_banner", "-nostats", "-i", src, "-vn",
            "-af", "silencedetect=noise=${noiseDb}dB:d=${f(minGap)}",
            "-f", "null", "-"
        ))
        val log = det.allLogsAsString ?: ""
        val starts = Regex("silence_start: (-?[0-9.]+)").findAll(log).map { max(it.groupValues[1].toDouble(), 0.0) }.toList()
        val ends = Regex("silence_end: ([0-9.]+)").findAll(log).map { it.groupValues[1].toDouble() }.toList()

        val pad = min(0.12, minGap / 3)
        val segs = mutableListOf<Seg>()
        var cur = 0.0
        for ((i, ss) in starts.withIndex()) {
            val end = min(ss + pad, duration)
            if (end - cur > 0.15) segs += Seg(cur, end)
            // শেষ নীরবতা ফাইলের শেষ পর্যন্ত গেলে end থাকে না
            cur = if (i < ends.size) max(ends[i] - pad, 0.0) else duration
        }
        if (duration - cur > 0.15) segs += Seg(cur, duration)
        if (segs.isEmpty()) error("কোনো কথা পাওয়া যায়নি। dB সীমা কমিয়ে (যেমন -45) আবার চেষ্টা করুন।")

        // --- ফিল্টার স্ক্রিপ্ট ---
        val g = grade.toFilter()
        val sb = StringBuilder()
        for ((i, s) in segs.withIndex()) {
            sb.append("[0:v]trim=start=${f(s.s)}:end=${f(s.e)},setpts=PTS-STARTPTS")
            if (g.isNotEmpty()) sb.append(",").append(g)
            sb.append(",fps=$fps,format=yuv420p,setsar=1[v$i];\n")
            sb.append("[0:a]atrim=start=${f(s.s)}:end=${f(s.e)},asetpts=PTS-STARTPTS,")
            sb.append("aformat=sample_rates=44100:channel_layouts=stereo[a$i];\n")
            if (i < segs.size - 1) {
                sb.append("color=c=black:s=${w}x$h:r=$fps:d=${f(blackSec)},format=yuv420p,setsar=1[bv$i];\n")
                sb.append("anullsrc=r=44100:cl=stereo,atrim=duration=${f(blackSec)},asetpts=PTS-STARTPTS[ba$i];\n")
            }
        }
        for (i in segs.indices) {
            sb.append("[v$i][a$i]")
            if (i < segs.size - 1) sb.append("[bv$i][ba$i]")
        }
        sb.append("concat=n=${segs.size * 2 - 1}:v=1:a=1[v][a]")
        val script = File(ctx.cacheDir, "filter.txt").apply { writeText(sb.toString()) }

        val totalOut = segs.sumOf { it.e - it.s } + blackSec * (segs.size - 1)
        FFmpegKitConfig.enableStatisticsCallback { st ->
            onProgress(((st.time / 1000.0) / totalOut * 100).toInt().coerceIn(0, 99))
        }

        // --- এক্সপোর্ট (আগে হার্ডওয়্যার এনকোডার, না হলে সফটওয়্যার) ---
        val out = File(ctx.cacheDir, "autocut_${System.currentTimeMillis()}.mp4")
        val encoders = listOf(
            arrayOf("-c:v", "h264_mediacodec", "-b:v", "10M"),
            arrayOf("-c:v", "mpeg4", "-q:v", "3")
        )
        for ((idx, enc) in encoders.withIndex()) {
            onStatus("এডিট ও এক্সপোর্ট হচ্ছে… (${segs.size}টি অংশ)")
            val args = arrayOf("-y", "-threads", "0", "-i", src, "-filter_complex_script", script.absolutePath,
                "-map", "[v]", "-map", "[a]") + enc +
                arrayOf("-c:a", "aac", "-b:a", "192k", "-movflags", "+faststart", out.absolutePath)
            val session = FFmpegKit.executeWithArguments(args)
            if (ReturnCode.isSuccess(session.returnCode)) {
                onProgress(100)
                return out
            }
            if (idx == encoders.lastIndex) {
                error("এক্সপোর্ট ব্যর্থ:\n" + (session.allLogsAsString ?: "").takeLast(600))
            }
        }
        error("অজানা সমস্যা")
    }
}
